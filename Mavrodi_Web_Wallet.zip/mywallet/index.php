<?php
define("IN_WALLET", true);
include_once('common.php');
$testing =0;
$mysqli = new Mysqli($db_host, $db_user, $db_pass, $db_name);
//var_dump($_SESSION);
if (!empty($_SESSION['user_session'])) 
{
    if(empty($_SESSION['token'])) 
	{
        $_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
    }
	
    $user_session = $_SESSION['user_session'];
	$my_wallet_address = isset($_SESSION['wallet_address'])?:'';
    $admin = false;
	
	
    if (!empty($_SESSION['user_admin']) && $_SESSION['user_admin']==1)
	{
        $admin = true;
    }
    $error = array('type' => "none", 'message' => "");
	$error3 = array('type' => "none", 'message' => "");
	
    $client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
//	var_dump($error);
//	die;
	if ($client == NULL)
	{
		$error['message']= "Could not connect to server";
	}

    $admin_action = false;
    if ($admin && !empty($_GET['a'])) 
	{
        $admin_action = $_GET['a'];
    }
    if (!$admin_action)
	{
			 $user = new User($mysqli);
			if($testing == 1)
			{
				$balance = $user->getBalance($_SESSION['user_id']);
				if(empty($_SESSION['wallet_address']))
				{
					$wallet_address = sha1($_SESSION['user_id'].rand(0,100000));
					$flag = $user->getNewAddress($_SESSION['user_id'],$wallet_address);
					if($flag)
					{
						$_SESSION['wallet_address']= $wallet_address;
					}
				}
			}
			else
			{
				$balance = $client->getBalance($user_session) - $fee;
	//			echo "<pre>1</pre>";
				if(empty($_SESSION['wallet_address']))
				{
	//				echo "<pre>2</pre>";
					$wallet_address  = $client->getnewaddress($user_session);
	//				echo "<pre>  s ";
//					echo $wallet_address;
//					echo " y</pre>";
					$json['success'] = true;
					$json['message'] = "A new address was added to your wallet";
					$json['balance'] = $client->getBalance($user_session) - $fee;
					$json['addressList'] = $client->getAddressList($user_session);
					$json['transactionList'] = $client->getTransactionList($user_session);
				//	$wallet_address =$json['addressList'][0];
					
					if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
					{
						$_SESSION['wallet_address']= $wallet_address;
					}
				}
			}
			if (!empty($_POST['jsaction']))
			{
				$json = array();
				switch ($_POST['jsaction'])
				{
					case "new_address":
						if($testing == 1)
						{
							if(empty($my_wallet_address))
							{
								$wallet_address = sha1($_SESSION['user_id'].rand(0,100000));
								if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
								{
									$my_wallet_address = $wallet_address;
									$_SESSION['wallet_address']= $wallet_address;
								}
							}
						}
						else 
						{
							if(empty($my_wallet_address))
							{
								$client->getnewaddress($user_session);
								$json['success'] = true;
								$json['message'] = "A new address was added to your wallet";
								$json['balance'] = $client->getBalance($user_session) - $fee;
								$json['addressList'] = $client->getAddressList($user_session);
								$json['transactionList'] = $client->getTransactionList($user_session);
								$wallet_address =$json['addressList'][0];
								
								if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
								{
									$my_wallet_address = $wallet_address;
									$_SESSION['wallet_address']= $wallet_address;
								}
							}
							else
							{
								$json['success'] = true;
								$json['message'] = "A new address was added to your wallet";
								$json['balance'] = $client->getBalance($user_session) - $fee;
								$json['addressList'] = $client->getAddressList($user_session);
								$json['transactionList'] = $client->getTransactionList($user_session);
							}
						}
						echo json_encode($json); exit;
					break;
					case "withdraw":
						$json['success'] = false;
						if (!WITHDRAWALS_ENABLED) 
						{
							$json['message'] = "Withdrawals are temporarily disabled";
						} 
						elseif (empty($_POST['address']) || empty($_POST['amount']) || !is_numeric($_POST['amount'])) 
						{
							$json['message'] = "You have to fill all the fields";
						}
						elseif ($_POST['token'] != $_SESSION['token'])
						{
							$json['message'] = "Tokens do not match";
							$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
							$json['newtoken'] = $_SESSION['token'];
						}
						elseif ($_POST['amount'] > $balance)
						{
							$json['message'] = "Withdrawal amount exceeds your wallet balance";
						}
						else
						{
                            
                           if(1)// if($user->checkOTP($_POST['optvalue']))
                            {
                                if(isset($client))
                                {
                                    $withdraw_message = $client->withdraw($user_session, $_POST['address'], (float)$_POST['amount']);
                                    $_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
                                    $json['newtoken'] = $_SESSION['token'];
                                    $json['success'] = true;
                                    $json['message'] = "Withdrawal successful";
                                    $json['balance'] = $client->getBalance($user_session);
                                    $json['addressList'] = $client->getAddressList($user_session);
                                    $json['transactionList'] = $client->getTransactionList($user_session);
                                }
                                else
                                {
                                    $json['message'] = "Could not connect to server";
                                }
                            }
                            else
                            {
                                $user->sendOTP($_SESSION['user_id']);
                                
                                $json['message'] = "An OTP has been send to your registered email id.";
                            }
                            
						}
						echo json_encode($json); exit;
					break;
					case "password":
						$user = new User($mysqli);
						$json['success'] = false;
						if (empty($_POST['oldpassword']) || empty($_POST['newpassword']) || empty($_POST['confirmpassword']))
						{
							$json['message'] = "You have to fill all the fields";
						}
						elseif ($_POST['token'] != $_SESSION['token'])
						{
							$json['message'] = "Tokens do not match";
							$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
							$json['newtoken'] = $_SESSION['token'];
						}
						else
						{
							$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
							$json['newtoken'] = $_SESSION['token'];
							$result = $user->updatePassword($user_session, $_POST['oldpassword'], $_POST['newpassword'], $_POST['confirmpassword']);
							if ($result === true)
							{
								$json['success'] = true;
								$json['message'] = "Password updated successfully.";
							}
							else
							{
								$json['message'] = $result;
							}
						}
						echo json_encode($json); exit;
					break;
            }
        }
        if (!empty($_POST['action']))
		{
			if($testing == 1)
			{
				if(empty($my_wallet_address))
				{
					$wallet_address = sha1($_SESSION['user_id'].rand(0,100000));
					if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
					{
						$my_wallet_address = $wallet_address;
						$_SESSION['wallet_address']= $wallet_address;
					}
				}
			}
			else 
			{
				if(empty($my_wallet_address))
				{
					$wallet_address = $client->getnewaddress($user_session);
					if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
					{
						$my_wallet_address = $wallet_address;
						$_SESSION['wallet_address']= $wallet_address;
					}
				}
			}
			
            switch ($_POST['action'])
			{
                case "new_address":
						if($testing == 1)
						{
							if(empty($my_wallet_address))
							{
								$wallet_address = sha1($_SESSION['user_id'].rand(0,100000));
								if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
								{
									$my_wallet_address = $wallet_address;
									$_SESSION['wallet_address']= $wallet_address;
								}
							}
						}
						else 
						{
							if(empty($my_wallet_address))
							{
								$wallet_address = $client->getnewaddress($user_session);
								if($user->getNewAddress($_SESSION['user_id'],$wallet_address))
								{
									$my_wallet_address = $wallet_address;
									$_SESSION['wallet_address']= $wallet_address;
								}
							}
						}
						header("Location: index.php");
                break;
                case "withdraw":
					if (!WITHDRAWALS_ENABLED)
					{
						$error3['type'] = "withdraw";
						$error3['message'] = "Withdrawals are temporarily disabled";
					}
					elseif (empty($_POST['address']) || empty($_POST['amount']) || !is_numeric($_POST['amount']))
					{
						$error3['type'] = "withdraw";
						$error3['message'] = "You have to fill all the fields";
					}
					elseif (strlen($_POST['address'])>34)
					{
						$error3['type'] = "withdraw";
						$error3['message'] = "Address cannot be more than 34 Characters";
					}
					
	//				elseif ($_POST['token'] != $_SESSION['token'])
		//			{
			//			$error3['type'] = "withdraw";
				//		$error3['message'] = "Tokens do not match";
					//	$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
					//}
					elseif ($_POST['amount'] > $balance)
					{
						$error3['type'] = "withdraw";
						$error3['message'] = "Withdrawal amount exceeds your wallet balance";
					} 
					else
					{
                        
                        if(1) //if($user->checkOTP($_SESSION['user_id'],$_POST['optvalue'],$_SESSION['wallet_address']))
                        {
                            if(isset($client))
                            {
                                $withdraw_message = $client->withdraw($user_session, $_POST['address'], (float)$_POST['amount']);
                            }
                            else
                            {
                            
                                $error3['message']= "Could not connect to server";
                            }
                            $_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
                            header("Location: index.php");
                            
                        }
                        else
                        {
                            $user->sendOTP($_SESSION['user_id'],$_POST['address'], (float)$_POST['amount'],$_SESSION['wallet_address']);
                            
                            $error3['message'] = "An OTP has been send to your registered email id.";
                        }
                        
			//			
					}
                break;
                case "password":
					$user = new User($mysqli);
					if (empty($_POST['oldpassword']) || empty($_POST['newpassword']) || empty($_POST['confirmpassword'])) {
						$error3['type'] = "password";
						$error3['message'] = "You have to fill all the fields";
					}
					elseif ($_POST['token'] != $_SESSION['token'])
					{
						$error3['type'] = "password";
						$error3['message'] = "Tokens do not match";
						$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
					}
					else
					{
						$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
						$result = $user->updatePassword($user_session, $_POST['oldpassword'], $_POST['newpassword'], $_POST['confirmpassword']);
						if ($result === true) 
						{
							$error3['message'] = "Password updated successfully.";
							header("Location: index.php");
						}
						else
						{
							$error3['type'] = "password";
							$error3['message'] = $result;
						}
					}
                break;
                case "logout":
					session_destroy();
					header("Location: index.php");
                break;
                case "support":
				//	$error['message'] = "Please contact support via email at $support";
				//	echo "Support Key: ";
				//	echo $_SESSION['user_supportpin'];
                break;
                case "authgen":
					$user = new User($mysqli);
					$secret = $user->createSecret();
					$gen=$user->enableauth();
					$_SESSION['auth'] = $gen;
					//echo $gen;
                break;
                
                case "disauth":
					$user = new User($mysqli);
					$disauth=$user->disauth();
				//	echo $disauth;
				$_SESSION['auth'] = $disauth;
                break;
            }
        }
		if(isset($client))
		{
			//echo "<pre> dd </br>";var_dump($_SESSION);echo "</br> ddd <pre>";
			$addressList = $client->getAddressList($user_session);
			$transactionList = $client->getTransactionList($user_session);
		}
		else
		{
			$error['message'] = "Could not connect to server";
		}
        include("view/header.php");
        include("view/wallet.php");
        include("view/footer.php");
    }
	else
	{
        $user = new User($mysqli);
        switch ($admin_action)
		{
            case "info":
            if (!empty($_GET['i']))
			{
                $info = $user->adminGetUserInfo($_GET['i']);
                if (!empty($info))
				{
					if(isset($client))
					{
						$info['balance'] = $client->getBalance($info['username']);
					}
					else
					{
						$info['message'] = "Could not connect to server";
					}
                    if (!empty($_POST['jsaction']))
					{
                        $json = array();
                        switch ($_POST['jsaction'])
						{
                            case "new_address":
								if(isset($client))
								{
									$client->getnewaddress($info['username']);
									$json['success'] = true;
									$json['message'] = "A new address was added to your wallet";
									$json['balance'] = $client->getBalance($info['username']);
									$json['addressList'] = $client->getAddressList($info['username']);
									$json['transactionList'] = $client->getTransactionList($info['username']);
								}
								else
								{
									$json['message'] = "Could not connect to server";
								}
								echo json_encode($json); exit;
                            break;
                            case "withdraw":
								$json['success'] = false;
								if (!WITHDRAWALS_ENABLED)
								{
									$json['message'] = "Withdrawals are temporarily disabled";
								}
								elseif (empty($_POST['address']) || empty($_POST['amount']) || !is_numeric($_POST['amount']))
								{
									$json['message'] = "You have to fill all the fields";
								}
								elseif ($_POST['amount'] > $info['balance'])
								{
									$json['message'] = "Withdrawal amount exceeds your wallet balance";
								}
								else
								{
									if(isset($client))
									{
										$withdraw_message = $client->withdraw($info['username'], $_POST['address'], (float)$_POST['amount']);
										$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
										$json['success'] = true;
										$json['message'] = "Withdrawal successful";
										$json['balance'] = $client->getBalance($info['username']);
										$json['addressList'] = $client->getAddressList($info['username']);
										$json['transactionList'] = $client->getTransactionList($info['username']);
									}
									else
									{
										$json['message'] = "Could not connect to server";
									}
								}
								echo json_encode($json); exit;
                            break;
                            case "password":
								$json['success'] = false;
								if ((is_numeric($_GET['i'])) && (!empty($_POST['password'])))
								{
									$result = $user->adminUpdatePassword($_GET['i'], $_POST['password']);
									if ($result === true)
									{
										$json['success'] = true;
										$json['message'] = "Password changed successfully.";
									}
									else
									{
										$json['message'] = $result;
									}
								}
								else
								{
									$json['message'] = "Something went wrong (at least one field is empty).";
								}
								echo json_encode($json); exit;
                            break;
                        }
                    }
                    if (!empty($_POST['action']))
					{
                        switch ($_POST['action'])
						{
                            case "new_address":
								if(isset($client))
								{
									$client->getnewaddress($info['username']);
								}
								else
								{
									$error['message'] = "Could not connect to server";
								}
								header("Location: index.php?a=info&i=" . $info['id']);
                            break;
                            case "withdraw":
								if (!WITHDRAWALS_ENABLED)
								{
									$error['type'] = "withdraw";
									$error['message'] = "Withdrawals are temporarily disabled";
								}
								elseif (empty($_POST['address']) || empty($_POST['amount']) || !is_numeric($_POST['amount']))
								{
									$error['type'] = "withdraw";
									$error['message'] = "You have to fill all the fields";
								}
								elseif ($_POST['amount'] > $info['balance'])
								{
									$error['type'] = "withdraw";
									$error['message'] = "Withdrawal amount exceeds your wallet balance";
								}
								else
								{
									if(isset($client))
									{
										$withdraw_message = $client->withdraw($info['username'], $_POST['address'], (float)$_POST['amount']);
									}
									else
									{
										$error['message'] = "Could not connect to server";
									}
									$_SESSION['token'] = sha1('@s%a$l£t#'.rand(0,10000));
									
									header("Location: index.php?a=info&i=" . $info['id']);
								}
                            break;
                            case "password":
								if ((is_numeric($_GET['i'])) && (!empty($_POST['password'])))
								{
									$result = $user->adminUpdatePassword($_GET['i'], $_POST['password']);
									if ($result === true)
									{
										$error['type'] = "password";
										$error['message'] = "Password changed successfully.";
										header("Location: index.php?a=info&i=" . $info['id']);
									}
									else
									{
										$error['type'] = "password";
										$error['message'] = $result;
									}
								}
								else
								{
									$error['type'] = "password";
									$error['message'] = "Something went wrong (at least one field is empty).";
								}
                            break;
                        }
                    }
					if(isset($client))
					{
						$addressList = $client->getAddressList($info['username']);
						$transactionList = $client->getTransactionList($info['username']);
					}
					else
					{
						$error['message'] = "Could not connect to server";
					}
                    unset($info['password']);
                }
            }
            include("view/header.php");
            include("view/admin_info.php");
            include("view/footer.php");
            break;
            default:
            if ((!empty($_GET['m'])) && (!empty($_GET['i'])))
			{
                switch ($_GET['m'])
				{
                    case "deadmin":
                    $user->adminDeprivilegeAccount($_GET['i']);
                    header("Location: index.php?a=home");
                    break;
                    case "admin":
                    $user->adminPrivilegeAccount($_GET['i']);
                    header("Location: index.php?a=home");
                    break;
                    case "unlock":
                    $user->adminUnlockAccount($_GET['i']);
                    header("Location: index.php?a=home");
                    break;
                    case "lock":
                    $user->adminLockAccount($_GET['i']);
                    header("Location: index.php?a=home");
                    break;
                    case "del":
                    $user->adminDeleteAccount($_GET['i']);
                    header("Location: index.php?a=home");
                    break;
                }
            }
            $userList = $user->adminGetUserList();
            include("view/header.php");
            include("view/admin_home.php");
            include("view/footer.php");
            break;
        }
    }
}
else
{
    $error = array('type' => "none", 'message' => "");
	$error2 = array('type' => "none", 'message' => "");
    if (!empty($_POST['action']))
	{
        $user = new User($mysqli);
        
        switch ($_POST['action'])
		{
            case "login":
				if(!ctype_alnum( $_POST['username']))
				{
					$error['type'] = "register";
					$error['message'] = "Only Alpha Numeric user Name allowed";
				}
				else if (strlen(trim(preg_replace('/\xc2\xa0/',' ',$_POST['password']))) == 0)
				{
					$error['type'] = "register";
					$error['message'] = "No Space is allowed in password";
				}
				else
				{
			
					$result = $user->logIn($_POST['username'], $_POST['password'], $_POST['auth']);
					if (!is_array($result))
					{
						$error['type'] = "login";
						$error['message'] = $result;
					}
					else
					{
						$_SESSION['user_session'] = $result['username'];
						$_SESSION['user_admin'] = $result['admin'];
						$_SESSION['user_supportpin'] = $result['supportpin'];
						$_SESSION['user_id'] = $result['id'];
						$_SESSION['wallet_address'] = $result['wallet_address'];
						header("Location: index.php");
					}
				}
            break;
            case "register":
			
				if(!ctype_alnum( $_POST['username']))
				{
					$error2['type'] = "register";
					$error2['message'] = "Only Alpha Numeric user Name allowed";
				}
				else if (strlen(trim(preg_replace('/\xc2\xa0/',' ',$_POST['password']))) == 0)
				{
					$error2['type'] = "register";
					$error2['message'] = "No Space is allowed in password";
				}
				
				else if (strlen(trim(preg_replace('/\xc2\xa0/',' ',$_POST['password']))) == 0)
				{
					$error2['type'] = "register";
					$error2['message'] = "No Space is allowed in password";
				}
				else if(!isEmail($_POST['emailId']))
				{
					$error2['type'] = "register";
					$error2['message'] = "Please Provide valid email ID";
					
				}
				
				else
				{
					$result = $user->add($_POST['username'], $_POST['password'], $_POST['confirmPassword'],$_POST['emailId']);
					if ($result !== true)
					{
						$error2['type'] = "register";
						$error2['message'] = $result;
					}
					else
					{
						$username   = $mysqli->real_escape_string(   strip_tags( $_POST['username']   ));
					//	$useri = $user->getUserIdFromUserName($username);
					//	$_SESSION['user_session'] = $username;
					//	$_SESSION['user_supportpin'] = "Please relogin for Support Key";
					//	$_SESSION['user_id'] = $useri['id'];
					//	$_SESSION['wallet_address'] = $result['wallet_address'];
						session_destroy();
						header("Location: index.php?s=1");
					}
				}
            break;
			 case "forgetpassword":
//                    var_dump($_POST);

				if(!isEmail($_POST['emailId']))
				{
					$error['type'] = "register";
					$error['message'] = "Please Provide valid email ID";
					
				}
				else
				{
					$result = $user->forgetPassword(trim($_POST['emailId']));
					if ($result !== true)
					{
						$error['type'] = "forgetpassword";
						$error['message'] = $result;
					}
					else
					{
						$error['message'] = $result;
						header("Location: index.php");
					}
				}
            break;
        }
    }
	else if (!empty($_GET['s']))
	{
			$error2['type'] = "register";
			$error2['message'] = "User Sucessfully Created";
			
	}
		
    include("view/header.php");
    include("view/home.php");
    include("view/footer.php");
}
$mysqli->close();
?>
