<?php
define("IN_WALLET", true);
include_once('common.php');
$mysqli = new Mysqli($db_host, $db_user, $db_pass, $db_name);
$format ="json";
$jsom = array();
$testing = 0;
if($_SERVER['REQUEST_METHOD'] == 'OPTIONS')
{
    return header("HTTP/1.0 200");
}
else
{
    if (isset($_GET['method']))
    {
		
        $jsonData = file_get_contents('php://input');
		$method = strtolower($_GET['method']);
        $parser = (isset($_REQUEST['parser']) ? $_REQUEST['parser'] : 'json');
		$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
		$user = new User($mysqli);
		$data = json_decode($jsonData, true);
//	echo "<pre>"; var_dump($jsonData); echo "</pre>";
		$validateUserAccess = $user->validateUser($data['authorizationcode']);
		$validateUserAccess = true;
		if($validateUserAccess == true)
		{
			switch ($method) 
			{
				case "authorizeadmin":
					$json['success'] = false;
					$result = $user->logIn($_POST['username'], $_POST['password']);
					if (!is_array($result))
					{
						$error['type'] = "login";
						$json['message'] = $result;
					}
					else
					{
						$json['success'] = true;
						$authorizationcode = hash('sha256',addslashes(strip_tags($username.rand(0,10000))));
						$json['authorizationcode'] = $authorizationcode;
						$user->storeAuthorizationKey($result['user_id'],$authorizationcode);
						
						
					}
					echo json_encode($json);
					exit;
				break;
				
				
				case "deactivateadminrole":
					$info = $user->getUserIdFromUserAddress($data['address']);
					$json['success'] = false;
					$json['address'] = $data['address'];
					if(empty($info))
					{
						$json['message'] = "No User found.";
					}
					else
					{
						$user->adminDeprivilegeAccount($info['id']);
						$json['success'] = true;
						$json['message'] = "Sucessfully deactive Admin Role.";
					}
					echo json_encode($json);
					exit;
				break;
				case "activateAdminRole":
					$info = $user->getUserIdFromUserAddress($data['address']);
					$json['success'] = false;
					$json['address'] = $data['address'];
					if(empty($info))
					{
						$json['message'] = "No User found.";
					}
					else
					{
						$user->adminPrivilegeAccount($info['id']);
						$json['success'] = true;
						$json['message'] = "Successfully Active Admin Role.";
					}
					echo json_encode($json);
					exit;
				break;
				case "unlockUser":
					$info = $user->getUserIdFromUserAddress($data['address']);
					$json['success'] = false;
					$json['address'] = $data['address'];
					if(empty($info))
					{
						$json['message'] = "No User found.";
					}
					else
					{
						$user->adminUnlockAccount($info['id']);
						$json['success'] = true;
						$json['message'] = "Successfully Unlock User.";
					}
					echo json_encode($json);
					exit;				
				break;
				case "lock":
					$json['success'] = false;
					$info = $user->getUserIdFromUserAddress($data['address']);
					$json['address'] = $data['address'];
					if(empty($info))
					{
						$json['message'] = "No User found.";
					}
					else
					{
						$user->adminLockAccount($info['id']);
						$json['success'] = true;
						$json['message'] = "Successfully Lock User.";
					}
					echo json_encode($json);
					exit;
				break;
				case "deleteUser":
					$json['success'] = false;
					$info = $user->getUserIdFromUserAddress($data['address']);
					$json['address'] = $data['address'];
					if(empty($info))
					{
						$json['message'] = "No User found.";
					}
					else
					{
						$user->adminDeleteAccount($info['id']);
						$json['success'] = true;
						$json['message'] = "Successfully Delete User.";
					}
					echo json_encode($json);
					exit;
				break;

				case "transactionList":
					$json['success'] = false;
					$json['address'] = $data['address'];
					if($testing == 1)
					{
							$transactionList = $user->getTransactionList($data['address']);
					}
					else
					{
						$user_name_array = $user->getUserNameFromUserAddress($data['address']);
						$transactionList = $client->getTransactionList($user_name_array['username']);
					}
					if(empty($transactionList))
					{
						$json['message'] = "No transaction List found.";
					}
					else
					{
						$json['success'] = true;
						$json['transaction_list']= $transactionList;
					}
					echo json_encode($json);
					exit;
				break;

				case "liveExchangeRate":
					$json['success'] = false;
					echo json_encode($json);
					exit;
				break;
				case "payoutdisbursementlist":
					
					$addressesCount = $data['count'];
					$json['success'] = false;
					$counter = 0;
					$retunArray = array();
					if($addressesCount >0)
					{
						foreach ($data['address_list'] as $address)
						{
							if($testing == 1)
							{	
								$txid = sha1(rand(0,100000));
							}
							else						
							{
								$txid = $client->payment($address['address'],$address['amount'],$address['comment']);
							}
							$retunArray[$counter]['request_id'] =$address['request_id'];
							$retunArray[$counter]['category'] =  "send";
							$retunArray[$counter]['time'] = date("d-m-Y H:i:s");
							$retunArray[$counter]['address'] = $address['address'];
							if(!empty($txid))
							{
								$retunArray[$counter]['status'] = 'complete';
								$retunArray[$counter]['txid'] = $txid;
								$user->transcation($data['admin_address'],$address['address'], $address['amount'], $txid, $address['comment']);
								
							}
							else
							{
								$retunArray[$counter]['status'] = 'pending';
								$retunArray[$counter]['txid'] = '';
							}
							$counter = $counter + 1;
						}
						$json['success'] = true;	
						$json['count'] = $counter;
						$json['transaction_list'] = $retunArray;
					}
					echo json_encode($json);
					exit;
				break;
			}
		}
		else
		{
			$json['success'] = false;
			$json['message'] = "Un Athorize Access";
			echo json_encode($json);
			exit;
			
		}
	}
}
$mysqli->close();
?>
