<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 'On');
session_start();
//header('Cache-control: private'); // IE 6
$testing = 0;
if(isSet($_GET['lang']))
{
$lang = $_GET['lang'];

// register the session and set the cookie
$_SESSION['lang'] = $lang;

setcookie('lang', $lang, time() + (3600 * 24 * 30));
}
else if(isSet($_SESSION['lang']))
{
$lang = $_SESSION['lang'];
}
else if(isSet($_COOKIE['lang']))
{
$lang = $_COOKIE['lang'];
}
else
{
$lang = 'en';
}

switch ($lang) {
  case 'en':
  $lang_file = 'lang.en.php';
  break;

  case 'grc':
  $lang_file = 'lang.grc.php';
  break;

  case 'zho':
  $lang_file = 'lang.zho.php';
  break;

  case 'ita':
  $lang_file = 'lang.ita.php';
  break;

  case 'por':
  $lang_file = 'lang.por.php';
  break;

  case 'hin':
  $lang_file = 'lang.hin.php';
  break;

  case 'spa':
  $lang_file = 'lang.spa.php';
  break;

  case 'tgl':
  $lang_file = 'lang.tgl.php';
  break;

  default:
  $lang_file = 'lang.en.php';

}

include_once 'languages/'.$lang_file;


define("WITHDRAWALS_ENABLED", true); //Disable withdrawals during maintenance

include('jsonRPCClient.php');
if($testing == 1)
{
	include('classes/Client_test.php');
}
else
{
	include('classes/Client.php');
}
include('classes/User.php');

// function by zelles to modify the number to bitcoin format ex. 0.00120000
function satoshitize($satoshitize2) {
   return sprintf("%.8f", $satoshitize2);
}

function isEmail($email)
{
	return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}



function getRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $string = '';

    for ($i = 0; $i < $length; $i++) {
        $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }

    return $string;
}


function getRandomOTPString($length = 8) {
    $string = '';
    $characters = '0123456789';

    for ($i = 0; $i < $length; $i++) {
        $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }

    return $string;
}




// function by zelles to trim trailing zeroes and decimal if need
function satoshitrim($satoshitrim) {
   return rtrim(rtrim($satoshitrim, "0"), ".");
}

$dir_path = "mywallet";
$server_ip = "70.38.54.7";//"70.38.54.7";
$server_url = "http://".$server_ip."/";  // website url

$dbserverflag =0;
if($dbserverflag == 1)
{
$db_host = "localhost";
$db_user = "root";
$db_pass = "karnal123";
$db_name = "bizchamp_wallet";
$testing = 0;
}
else
{
$db_host = "localhost";
$db_user = "root";
$db_pass = "karnal123";
$db_name = "bizchamp_wallet";
$testing = 1;
}
$rpc_host = "127.0.0.1";
//$rpc_port = "";
//$rpc_user = "";
//$rpc_pass = "";

$rpc_user="ChampCoin7";
$rpc_pass="ChampCoin$123";
$rpc_port="45632";

$fullname = "Champ Coin"; //Website Title (Do Not include 'wallet')
$short = "Champ"; //Coin Short 
$server_name = "http://70.38.54.7";

$blockchain_url = "http://".$server_ip.":3003/tx/"; //Blockchain Url
$support = "donotreply@champcoin.com"; //Your support eMail
$hide_ids = array(1); //Hide account from admin dashboard
$donation_address = "NUQ5EQVo2BVV7ENwPbYD854dCp85cVFrCB"; //Donation Address

$fee = "0.000"; //Set a fee to prevent negitive balances.  	
?>
