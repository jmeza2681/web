For Upload coin Web Wallet

1. create database in my sql
2. import database from Scrpt wallet.sql
3. open file common.php
4. Replace "mywallet" at  Line number 123 $dir_path = "mywallet"; to wallet directory name.
5. 