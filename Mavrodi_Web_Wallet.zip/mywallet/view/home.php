<?php if (!defined("IN_WALLET")) { die("Auth Error"); } ?>
					<div class="row">
                        <div class="col-sm-5">
				<?php
					//	var_dump($error);
						if (!empty($error['message']))
						{
?>							<div class="form-box">
								<div class="form-top">
	                        		<div class="form-top-left2"><h3><?php echo $error['message']; ?></h3></div>
								</div>
							</div>
				<?php	}?>
                        	<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Login to your Wallet</h3>
	                            		<p>Enter credentials to log on:</p>
	                        		</div>
	                        		<div class="form-top-right">
	                        			<i class="fa fa-lock"></i>
	                        		</div>
	                            </div>
	                            <div class="form-bottom">		
									<form action="index.php" method="POST" class="clearfix">
										<input type="hidden" name="action" value="login" />
										<div class="form-group"><input type="text" class="form-control" name="username" placeholder="Alpha Numeric <?php echo $lang['FORM_USER']; ?>" ></div>
										<div class="form-group"><input type="password" class="form-control" name="password" placeholder="Without Space <?php echo $lang['FORM_PASS']; ?>"></div>
									<div class="form-group"><input type = "hidden" class="form-control" name="auth" placeholder="<?php echo $lang['FORM_2FA']; ?>"></div> 
										<button type="submit" class="btn btn-default"><?php echo $lang['FORM_LOGIN']; ?></button>
									</form>
			                    </div>
		                    </div>
							
						</div>
						<div class="col-sm-1 middle-border"></div>
                        <div class="col-sm-1"></div>
                        <div class="col-sm-5">
						<?php
					//	var_dump($error);
						if (!empty($error2['message']))
						{
?>							<div class="form-box">
								<div class="form-top">
	                        		<div class="form-top-left2"><h3><?php echo $error2['message']; ?></h3></div>
								</div>
							</div>
				<?php	}?>
                        	<div class="form-box">
                        		<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Sign up now</h3>
	                            		<p>Just Fill in the form below:</p>
	                        		</div>
	                        		<div class="form-top-right">
	                        			<i class="fa fa-pencil"></i>
	                        		</div>
	                            </div>
	                            <div class="form-bottom">
									<form action="index.php" method="POST" class="clearfix">
										<input type="hidden" name="action" value="register" />
										<div class="form-group"><input type="text" class="form-control" name="username" placeholder="Alpha Numeric <?php echo $lang['FORM_USER']; ?>" ></div>
										<div class="form-group"><input type="password" class="form-control" name="password" placeholder="Without Space <?php echo $lang['FORM_PASS']; ?>"></div>
										<div class="form-group"><input type="password" class="form-control" name="confirmPassword" placeholder="<?php echo $lang['FORM_PASSCONF']; ?>"></div>
										<div class="form-group"><input type="text" class="form-control" name="emailId" placeholder="Email Id"></div>
										<button type="submit" class="btn btn-default"><?php echo $lang['FORM_SIGNUP']; ?></button>
									</form>
								</div>
                        	</div>
                        </div>						
                    </div>
					<div class="horz-border"></div>
					<div class="row">
						<div class="col-sm-2"></div>
						<div class="col-sm-7" style="margin-left:40px">
                        	<div class="form-box">
                        		<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Forgot Password</h3>
	                            		<p>Enter valid email to retrive your credentials:</p>
	                        		</div>
	                        		<div class="form-top-right">
	                        			<i class="fa fa-unlock"></i>
	                        		</div>
	                            </div>
	                            <div class="form-bottom">
									<form action="index.php" method="POST" class="clearfix">
									<input type="hidden" name="action" value="forgetpassword" />
										<div class="form-group col-sm-7" ><input type="text" class="form-control" name="emailId" placeholder="Email Id"></div>
										<div class="col-sm-4"><button type="submit" class="btn btn-default">Forget Password</button></div>
										</div>
									</form>
								</div>
                        	</div>
                        </div>
						</div>
                </div>
            </div>
            
        </div>
                