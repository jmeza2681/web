<?php if (!defined("IN_WALLET")) { die("Auth Error!"); } ?>
<!DOCTYPE HTML>
<html>
    <head>
      <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
   <!--     <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500"> -->
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/stacktable.css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
		<title><?php echo $fullname;?> Wallet</title>
   </head>
    <body>
        <div class="top-content">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<div class="navbar-header">
						<a class="navbar-brand" href="index.php">
						<img src="assets/img/logo.jpg" alt="<?=$fullname?> Wallet" class="logoImg"></a>
					</div>
				<?php if (!empty($_SESSION['user_session'])) {
				$acn_btc = 0;
//$jsnsrc = "https://blockchain.info/ticker";
if($testing != 1)
{
$jsnsrc = "https://c-cex.com/t/acn-btc.json";
$json = file_get_contents($jsnsrc);
$json = json_decode($json);
//print_r($json);
$acn_btc = $json->ticker->buy; 
//$one_Btc_To_Brl = $json->BRL->last;		
}
else
{
    $acn_btc = 1;
}    
					?>
					<div class="nav nav-center2">
						<h3> Welcome,
							<strong><?php echo $user_session."( ".$_SESSION['wallet_address']." )"; ?></strong>
							<img src="http://chart.apis.google.com/chart?cht=qr&chs=300x300&chl=<?php echo $_SESSION['wallet_address'];?>" alt="QR Code" style="width:52px;height:52px;border:0;">
							<?php if ($admin) {?><font color="red">[Admin]</font><?php }?><br />
							<span style="font-size:14px; font-weight:bolder"><b>Current Balance <?php echo $short;?>:
							<span style="color:#0000ff"><?php echo satoshitize($balance); ?></span>
							<!--<span style="margin-left:20px">Live Rate <?php echo $short;?>-BTC : <?php echo satoshitize($acn_btc); ?></span> -->
							<span style="margin-left:20px;"> BTC : <span style="color:#ff0000;"> <?php //echo satoshitize($acn_btc * $balance); ?> BTC</b></span>
							</span>
							
						</h3>
					</div>
				<?php } else {?> 
					<div class="nav nav-center">
						<h1><strong><?php echo $fullname;?> (<?php echo $short;?>) Wallet<strong><h1>
				<?php }?>
					</div>
				
			</nav>	
		
		    <div class="inner-bg">
                <div class="container">
				<?php if (!empty($_SESSION['user_session'])) {?>
				<?php if ($admin){?>
					<div class="menunavbar"style ="margin-left:40px;">

						<div>
							<a href="?a=home" class="btn btn-default">Admin Dashboard</a>
						</div>
			<?php } else {?>
					<div class="menunavbar" style ="margin-left:15%;">
						<?php } ?>
						<div>
							<form action="index.php" method="POST">
								<input type="hidden" name="action" value="authgen" />
								<button type="submit" class="btn btn-default"><?php echo $lang['WALLET_2FAON']; ?></button>
							</form>
					</div>
					<div>
						<form action="index.php" method="post">
							<input type="hidden" name="action" value="disauth" />
							<button type="submit" class="btn btn-default"><?php echo $lang['WALLET_2FAOFF']; ?></button>
						</form>
					</div>
					<div style="border-right:1px solid #ccc;">	
						<form action="index.php" method="POST">
							<input type="hidden" action="index.php" name="action" value="logout" />
							<button type="submit" class="btn btn-default"><?php echo $lang['WALLET_LOGOUT']; ?></button>
						</form>
					</div>
					<div>
						<a class="btn" style="background-color:none;color:#000;" href="mail:<?php echo $support;?>"><?php echo $support;?></a>
					</div>
						
				</div>
				<br/>
				<?php }?>
        
