<?php if (!defined("IN_WALLET")) { die("Auth Error!"); } ?>
<?php if(isset($_SESSION['auth'])) {?>
<div class="col-sm-12"><br/><div class="horz-border"></div></div>
					<div class="row">
                        <div class="col-sm-12">
							<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>2 Factor Authorization</h3><br/>
										
	                        		</div>
	                            </div>
								<div class="form-bottom" style="padding:15px;">
									<?php $val = explode("<br>",$_SESSION['auth']);?>
									<div class="form-group col-sm-1"><?php if(isset($val[1])){echo $val[1].'style="width:60px;height:60px;border:0;">';}?>
									</div>
									<div class="form-group col-sm-9" style="color:#fff;margin-top:15px"><?php echo $val[0];?>
									</div>
									<br/><br/>
									</div>
						</div>
					</div>
				</div>
				<div class="col-sm-12"><br/></div>
<?php }?>


					<div class="col-sm-12"><br/><div class="horz-border"></div></div>
					<div class="row">
                        <div class="col-sm-12">
							<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Make Payment</h3>
	                        		</div>
	                            </div>
								<div class="form-bottom">
									<form action="index.php" method="POST" class="clearfix" id="withdrawform"
									onSubmit="if(!confirm('Do you want to continue the transcation?',2)){return false;}"
									
									>
										<input type="hidden" name="action" value="withdraw" />
										<input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
										<div class="form-group col-sm-5"><input type="text" size = "34" class="form-control" name="address" 
                                        placeholder="<?php echo $lang['WALLET_ADDRESS']; ?>" value = "<?php if(isset($_POST['address'])){echo $_POST['address'];}?>" >
                                        </div>
										<div class="form-group col-sm-2"><input type="text" class="form-control" name="amount" 
                                        value = "<?php if(isset($_POST['amount'])){echo $_POST['amount'];}?>"
                                        placeholder="<?php echo $lang['WALLET_AMOUNT']; ?>"></div>
										<div class="form-group col-sm-2"><input type="hidden" class="form-control" name="optvalue" placeholder="OTP"></div>
										<div class="form-group col-sm-2"><button type="submit" class="btn btn-default"><?php echo $lang['WALLET_SENDCONF']; ?></button></div>
								<?php
									if (!empty($error3['message']))
									{?>
								
										<div class="form-top-left2"><h3><?php echo $error3['message']; ?></h3></div>
								<?php }?>
								</form>
								<p id="withdrawmsg"></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-12"><br/><div class="horz-border"></div></div>
					<div class="row">
                        <div class="col-sm-12">
							<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3><?php echo $lang['WALLET_LAST10']; ?></h3>
	                        		</div>
	                            </div>
								<div class="form-bottom">
									<table class="table table-bordered table-striped" id="txlist">
										<thead>
											<tr>
											  <th ><?php echo $lang['WALLET_DATE']; ?></th>
											  <th><?php echo $lang['WALLET_ADDRESS']; ?></th>
										<!--	  <th><?php echo $lang['WALLET_TYPE']; ?></th> -->
											  <th><?php echo $lang['WALLET_AMOUNT']; ?></th>
									<!--		  <th><?php echo $lang['WALLET_FEE']; ?></th> -->
											  <th><?php echo $lang['WALLET_CONFS']; ?></th>
											<!--  <th><?php echo $lang['WALLET_INFO']; ?></th> -->
											</tr>
										</thead>
										<tbody>
<?php
   $bold_txxs = "";
   $transactionList2 = array();
   $transactionList2 = $transactionList;
   foreach($transactionList as $transaction) 
   {
  		//$tx_type = '<b style="color: #FF0000;">Sent</b>'; } else { $tx_type = '<b style="color: #01DF01;">Received</b>'; }
		echo '<tr>
               <td>'.date('n/j/Y h:i a',$transaction['time']).'</td>
               <td>'.$transaction['address'].'</td>
               <td>'.abs($transaction['amount']).'</td>
               <td>'.$transaction['confirmations'].'</td>
            </tr>';
		}
   //        <td>'.$tx_type.'</td>
       
//                  <td>'.$transaction['fee'].'</td>
//<td><a href="' . $blockchain_url,  $transaction['txid'] . '" target="_blank">Info</a></td>

   ?>
								   </tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-12"><br/><div class="horz-border"></div></div>
					<div class="row">
                        <div class="col-sm-12">
							<div class="form-box">
	                        	<div class="form-top">
	                        		<div class="form-top-left">
	                        			<h3>Change Password</h3>
	                        		</div>
	                            </div>
								<div class="form-bottom">
									<form action="index.php" method="POST" class="clearfix" id="pwdform">
										<input type="hidden" name="action" value="password" />
										<input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
										<div class="form-group col-sm-3"><input type="password" class="form-control" name="oldpassword" placeholder="<?php echo $lang['WALLET_PASSUPDATEOLD']; ?>"></div>
										<div class="form-group col-sm-3"><input type="password" class="form-control" name="newpassword" placeholder="<?php echo $lang['WALLET_PASSUPDATENEW']; ?>"></div>
										<div class="form-group col-sm-3"><input type="password" class="form-control" name="confirmpassword" placeholder="<?php echo $lang['WALLET_PASSUPDATENEWCONF']; ?>"></div>
										<div class="form-group col-sm-3"><button type="submit" class="btn btn-default"><?php echo $lang['WALLET_PASSUPDATECONF']; ?></button></div>
								<?php
									if (!empty($error4['message']))
									{?>
								
										<div class="form-top-left2"><h3><?php echo $error4['message']; ?></h3></div>
								<?php }?>
								</form>
								<p id="withdrawmsg"></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-12"><br/></div>